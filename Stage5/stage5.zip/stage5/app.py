"""
Complete Flask GUI Application for Postgres Database Management
University Project - Gym Equipment & Training Management System
"""

# app.py - Main Flask Application
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from datetime import datetime, timedelta
import os
from dotenv import load_dotenv
import logging
import sys

# Load environment variables from .env file
load_dotenv(dotenv_path='env')  # מציין במפורש את שם הקובץ שלך

app = Flask(__name__)

# Configuration with environment variables
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'your-secret-key-here')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL',
                                                       'postgresql://username:password@localhost:5432/dbname')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    'pool_pre_ping': True,
    'pool_recycle': 300,
    'connect_args': {"options": "-c timezone=utc"}
}

# Initialize extensions
db = SQLAlchemy(app)
migrate = Migrate(app, db)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(name)s %(message)s'
)
logger = logging.getLogger(__name__)

# Test database connection
def test_db_connection():
    """Test database connection on startup"""
    try:
        with app.app_context():
            # Test connection
            db.session.execute(db.text('SELECT 1'))
            logger.info("✅ Database connection successful!")
            logger.info(f"Connected to: {app.config['SQLALCHEMY_DATABASE_URI'].split('@')[1] if '@' in app.config['SQLALCHEMY_DATABASE_URI'] else 'Unknown'}")
            return True
    except Exception as e:
        logger.error(f"❌ Database connection failed: {str(e)}")
        return False

# ===============================
# DATABASE MODELS
# ===============================

class Employee(db.Model):
    __tablename__ = 'employee'
    employeeid = db.Column(db.Integer, primary_key=True)
    phone_number = db.Column(db.String(20), unique=True, nullable=False)

    # Relationships
    trainers = db.relationship('Trainer', backref='employee', lazy=True)
    technicians = db.relationship('MaintenanceTechnician', backref='employee', lazy=True)

    def __repr__(self):
        return f'<Employee {self.employeeid}>'


class Equipment(db.Model):
    __tablename__ = 'equipment'
    equipment_id = db.Column(db.Integer, primary_key=True)
    equipment_name = db.Column(db.String(100), nullable=False)
    equipment_type = db.Column(db.String(50), nullable=False)
    safety_status = db.Column(db.String(20), nullable=False)
    installation_date = db.Column(db.Date, nullable=False)
    standard_id = db.Column(db.Integer, db.ForeignKey('safety_standard.standard_id'))
    exerciseid = db.Column(db.Integer, db.ForeignKey('exercise.exerciseid'))
    conditionstatus = db.Column(db.String(20), nullable=False)
    purchasedate = db.Column(db.Date, nullable=False)

    # Relationships
    malfunctions = db.relationship('EquipmentMalfunction', backref='equipment', lazy=True, cascade='all, delete-orphan')
    usage_logs = db.relationship('EquipmentUsage', backref='equipment', lazy=True, cascade='all, delete-orphan')
    safety_checks = db.relationship('SafetyCheck', backref='equipment', lazy=True, cascade='all, delete-orphan')

    def __repr__(self):
        return f'<Equipment {self.equipment_name}>'


class EquipmentMalfunction(db.Model):
    __tablename__ = 'equipment_malfunction'
    malfunction_id = db.Column(db.Integer, primary_key=True)
    report_date = db.Column(db.Date, nullable=False)
    malfunction_severity = db.Column(db.String(20), nullable=False)
    repair_status = db.Column(db.String(20), nullable=False)
    equipment_id = db.Column(db.Integer, db.ForeignKey('equipment.equipment_id'), nullable=False)
    technician_id = db.Column(db.Integer, db.ForeignKey('maintenance_technician.technician_id'))

    def __repr__(self):
        return f'<Malfunction {self.malfunction_id}>'


class EquipmentUsage(db.Model):
    __tablename__ = 'equipment_usage'
    usage_id = db.Column(db.Integer, primary_key=True)
    equipment_id = db.Column(db.Integer, db.ForeignKey('equipment.equipment_id'), nullable=False)
    user_id = db.Column(db.Integer, nullable=False)
    start_time = db.Column(db.DateTime, nullable=False)
    usage_duration = db.Column(db.Integer, nullable=False)  # in minutes

    def __repr__(self):
        return f'<Usage {self.usage_id}>'


class Exercise(db.Model):
    __tablename__ = 'exercise'
    exerciseid = db.Column(db.Integer, primary_key=True)
    exname = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    programid = db.Column(db.Integer, db.ForeignKey('trainingprogram.programid'))

    # Relationships
    equipment = db.relationship('Equipment', backref='exercise', lazy=True)

    def __repr__(self):
        return f'<Exercise {self.exname}>'


class MaintenanceTechnician(db.Model):
    __tablename__ = 'maintenance_technician'
    technician_id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100), nullable=False)
    professional_certifications = db.Column(db.Text)
    phone_number = db.Column(db.String(20), nullable=False)
    last_certification_date = db.Column(db.Date)
    employeeid = db.Column(db.Integer, db.ForeignKey('employee.employeeid'), unique=True)

    # Relationships
    malfunctions = db.relationship('EquipmentMalfunction', backref='technician', lazy=True)

    def __repr__(self):
        return f'<Technician {self.full_name}>'


class SafetyCheck(db.Model):
    __tablename__ = 'safety_check'
    check_id = db.Column(db.Integer, primary_key=True)
    equipment_id = db.Column(db.Integer, db.ForeignKey('equipment.equipment_id'), nullable=False)
    result = db.Column(db.String(20), nullable=False)
    inspector_notes = db.Column(db.Text)
    inspection_date = db.Column(db.Date, nullable=False)

    def __repr__(self):
        return f'<SafetyCheck {self.check_id}>'


class SafetyStandard(db.Model):
    __tablename__ = 'safety_standard'
    standard_id = db.Column(db.Integer, primary_key=True)
    standard_name = db.Column(db.String(100), nullable=False)
    safety_requirements_description = db.Column(db.Text)
    standard_level = db.Column(db.String(20), nullable=False)
    equipment_type = db.Column(db.String(50), nullable=False)

    # Relationships
    equipment = db.relationship('Equipment', backref='safety_standard', lazy=True)

    def __repr__(self):
        return f'<SafetyStandard {self.standard_name}>'


class Trainee(db.Model):
    __tablename__ = 'trainee'
    traineeid = db.Column(db.Integer, primary_key=True)
    firstname = db.Column(db.String(50), nullable=False)
    lastname = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    phone = db.Column(db.String(20))
    dateofbirth = db.Column(db.Date, nullable=False)

    # Relationships
    training_programs = db.relationship('TrainingProgram', backref='trainee', lazy=True)
    training_logs = db.relationship('TrainingLog', backref='trainee', lazy=True)

    def __repr__(self):
        return f'<Trainee {self.firstname} {self.lastname}>'

    @property
    def full_name(self):
        return f"{self.firstname} {self.lastname}"


class Trainer(db.Model):
    __tablename__ = 'trainer'
    trainerid = db.Column(db.Integer, primary_key=True)
    programid = db.Column(db.Integer, db.ForeignKey('trainingprogram.programid'))
    hiredate = db.Column(db.Date, nullable=False)
    phone_number = db.Column(db.String(20), nullable=False)
    employeeid = db.Column(db.Integer, db.ForeignKey('employee.employeeid'), unique=True)

    def __repr__(self):
        return f'<Trainer {self.trainerid}>'


class TrainingLog(db.Model):
    __tablename__ = 'traininglog'
    logid = db.Column(db.Integer, primary_key=True)
    traineeid = db.Column(db.Integer, db.ForeignKey('trainee.traineeid'), nullable=False)
    programid = db.Column(db.Integer, db.ForeignKey('trainingprogram.programid'), nullable=False)
    duration = db.Column(db.Integer, nullable=False)  # in minutes
    repetitions = db.Column(db.Integer)
    programname = db.Column(db.String(100), nullable=False)

    def __repr__(self):
        return f'<TrainingLog {self.logid}>'


class TrainingProgram(db.Model):
    __tablename__ = 'trainingprogram'
    programid = db.Column(db.Integer, primary_key=True)
    programname = db.Column(db.String(100), nullable=False)
    startdate = db.Column(db.Date, nullable=False)
    enddate = db.Column(db.Date, nullable=False)
    traineeid = db.Column(db.Integer, db.ForeignKey('trainee.traineeid'))

    # Relationships
    exercises = db.relationship('Exercise', backref='training_program', lazy=True)
    trainers = db.relationship('Trainer', backref='training_program', lazy=True)
    training_logs = db.relationship('TrainingLog', backref='training_program', lazy=True)

    def __repr__(self):
        return f'<TrainingProgram {self.programname}>'

    @property
    def is_active(self):
        today = datetime.now().date()
        return self.startdate <= today <= self.enddate


def get_next_malfunction_number():
    """Return the next malfunction number for ID generation"""
    try:
        last_id = db.session.execute(db.text("SELECT MAX(malfunction_id) FROM equipment_malfunction")).scalar()
        if last_id:
            parts = last_id.split('_')
            number = int(parts[1]) if len(parts) >= 2 and parts[1].isdigit() else 0
            return number + 1
        else:
            return 1
    except Exception as e:
        logger.error(f"Error fetching last malfunction ID: {str(e)}")
        return 1


# ===============================
# ROUTES - DASHBOARD
# ===============================

@app.route('/')
def dashboard():
    """Main dashboard with quick stats and overview"""
    try:
        # Calculate dashboard statistics
        total_trainees = Trainee.query.count()
        total_equipment = Equipment.query.count()
        active_equipment = Equipment.query.filter_by(safety_status='Active').count()
        pending_malfunctions = EquipmentMalfunction.query.filter_by(repair_status='Pending').count()

        # Recent activities
        recent_malfunctions = EquipmentMalfunction.query.order_by(EquipmentMalfunction.report_date.desc()).limit(5).all()
        recent_training_logs = TrainingLog.query.order_by(TrainingLog.logid.desc()).limit(5).all()

        # Equipment needing inspection (older than 30 days)
        inspection_cutoff = datetime.now().date() - timedelta(days=30)
        equipment_needing_inspection = Equipment.query.outerjoin(SafetyCheck).filter(
            db.or_(SafetyCheck.inspection_date < inspection_cutoff, SafetyCheck.inspection_date.is_(None))
        ).count()

        stats = {
            'total_trainees': total_trainees,
            'total_equipment': total_equipment,
            'active_equipment': active_equipment,
            'pending_malfunctions': pending_malfunctions,
            'equipment_needing_inspection': equipment_needing_inspection
        }

        return render_template('dashboard.html',
                               stats=stats,
                               recent_malfunctions=recent_malfunctions,
                               recent_training_logs=recent_training_logs)
    except Exception as e:
        logger.error(f"Dashboard error: {str(e)}")
        flash(f'Error loading dashboard: {str(e)}', 'error')
        return render_template('dashboard.html', stats={}, recent_malfunctions=[], recent_training_logs=[])


# ===============================
# ROUTES - EQUIPMENT MANAGEMENT
# ===============================

@app.route('/equipment')
def equipment_list():
    """Display all equipment with filtering options"""
    try:

        # Get filter parameters
        equipment_type = request.args.get('equipment_type', '')
        safety_status = request.args.get('safety_status', '')

        # Build query with filters
        query = Equipment.query
        if equipment_type:
            query = query.filter(Equipment.equipment_type.ilike(f'%{equipment_type}%'))
        if safety_status:
            query = query.filter_by(safety_status=safety_status)

        equipment = query.order_by(Equipment.equipment_id).all()

        # Get unique values for filter dropdowns
        equipment_types = db.session.query(Equipment.equipment_type.distinct()).all()
        safety_statuses = db.session.query(Equipment.safety_status.distinct()).all()

        return render_template('equipment/list.html',
                               equipment=equipment,
                               equipment_types=[t[0] for t in equipment_types],
                               safety_statuses=[s[0] for s in safety_statuses],
                               current_filters={'equipment_type': equipment_type, 'safety_status': safety_status})
    except Exception as e:
        logger.error(f"Equipment list error: {str(e)}")
        flash(f'Error loading equipment: {str(e)}', 'error')
        return render_template('equipment/list.html', equipment=[], equipment_types=[], safety_statuses=[])


@app.route('/equipment/add', methods=['GET', 'POST'])
def equipment_add():
    """Add new equipment"""
    if request.method == 'POST':
        try:
            equipment = Equipment(
                equipment_name=request.form['equipment_name'],
                equipment_type=request.form['equipment_type'],
                safety_status=request.form['safety_status'],
                installation_date=datetime.strptime(request.form['installation_date'], '%Y-%m-%d').date(),
                conditionstatus=request.form['conditionstatus'],
                purchasedate=datetime.strptime(request.form['purchasedate'], '%Y-%m-%d').date(),
                standard_id=request.form['standard_id'] if request.form['standard_id'] else None,
                exerciseid=request.form['exerciseid'] if request.form['exerciseid'] else None
            )

            db.session.add(equipment)
            db.session.commit()
            flash('Equipment added successfully!', 'success')
            return redirect(url_for('equipment_list'))
        except Exception as e:
            db.session.rollback()
            logger.error(f"Equipment add error: {str(e)}")
            flash(f'Error adding equipment: {str(e)}', 'error')

    # Get data for dropdowns
    safety_standards = SafetyStandard.query.all()
    exercises = Exercise.query.all()

    return render_template('equipment/add.html', safety_standards=safety_standards, exercises=exercises)


@app.route('/equipment/edit/<int:equipment_id>', methods=['GET', 'POST'])
def equipment_edit(equipment_id):
    """Edit existing equipment"""
    from sqlalchemy import cast, Integer  # הוסף למעלה אם לא קיים

    equipment = Equipment.query.filter(
        cast(Equipment.equipment_id, Integer) == equipment_id
    ).first_or_404()

    if request.method == 'POST':
        try:
            equipment.equipment_name = request.form['equipment_name']
            equipment.equipment_type = request.form['equipment_type']
            equipment.safety_status = request.form['safety_status']
            equipment.installation_date = datetime.strptime(request.form['installation_date'], '%Y-%m-%d').date()
            equipment.conditionstatus = request.form['conditionstatus']
            equipment.purchasedate = datetime.strptime(request.form['purchasedate'], '%Y-%m-%d').date()
            equipment.standard_id = request.form['standard_id'] if request.form['standard_id'] else None
            equipment.exerciseid = request.form['exerciseid'] if request.form['exerciseid'] else None

            db.session.commit()
            flash('Equipment updated successfully!', 'success')
            return redirect(url_for('equipment_list'))
        except Exception as e:
            db.session.rollback()
            logger.error(f"Equipment edit error: {str(e)}")
            flash(f'Error updating equipment: {str(e)}', 'error')

    # Get data for dropdowns
    safety_standards = SafetyStandard.query.all()
    exercises = Exercise.query.all()

    return render_template('equipment/edit.html', equipment=equipment, safety_standards=safety_standards, exercises=exercises)


@app.route('/equipment/delete/<int:equipment_id>')
def equipment_delete(equipment_id):
    """Delete equipment"""
    try:
        equipment = Equipment.query.get_or_404(equipment_id)
        db.session.delete(equipment)
        db.session.commit()
        flash('Equipment deleted successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        logger.error(f"Equipment delete error: {str(e)}")
        flash(f'Error deleting equipment: {str(e)}', 'error')

    return redirect(url_for('equipment_list'))


# ===============================
# ROUTES - TRAINEE MANAGEMENT
# ===============================

@app.route('/trainees')
def trainee_list():
    """Display all trainees"""
    try:
        search = request.args.get('search', '')
        query = Trainee.query

        if search:
            query = query.filter(
                db.or_(
                    Trainee.firstname.ilike(f'%{search}%'),
                    Trainee.lastname.ilike(f'%{search}%'),
                    Trainee.email.ilike(f'%{search}%')
                )
            )

        trainees = query.order_by(Trainee.lastname, Trainee.firstname).all()
        return render_template('trainees/list.html', trainees=trainees, search=search)
    except Exception as e:
        logger.error(f"Trainee list error: {str(e)}")
        flash(f'Error loading trainees: {str(e)}', 'error')
        return render_template('trainees/list.html', trainees=[], search='')


@app.route('/trainees/add', methods=['GET', 'POST'])
def trainee_add():
    """Add new trainee"""
    if request.method == 'POST':
        try:
            trainee = Trainee(
                firstname=request.form['firstname'],
                lastname=request.form['lastname'],
                email=request.form['email'],
                phone=request.form['phone'],
                dateofbirth=datetime.strptime(request.form['dateofbirth'], '%Y-%m-%d').date()
            )

            db.session.add(trainee)
            db.session.commit()
            flash('Trainee added successfully!', 'success')
            return redirect(url_for('trainee_list'))
        except Exception as e:
            db.session.rollback()
            logger.error(f"Trainee add error: {str(e)}")
            flash(f'Error adding trainee: {str(e)}', 'error')

    return render_template('trainees/add.html')


@app.route('/trainees/edit/<int:trainee_id>', methods=['GET', 'POST'])
def trainee_edit(trainee_id):
    """Edit existing trainee"""
    trainee = Trainee.query.get_or_404(trainee_id)

    if request.method == 'POST':
        try:
            trainee.firstname = request.form['firstname']
            trainee.lastname = request.form['lastname']
            trainee.email = request.form['email']
            trainee.phone = request.form['phone']
            trainee.dateofbirth = datetime.strptime(request.form['dateofbirth'], '%Y-%m-%d').date()

            db.session.commit()
            flash('Trainee updated successfully!', 'success')
            return redirect(url_for('trainee_list'))
        except Exception as e:
            db.session.rollback()
            logger.error(f"Trainee edit error: {str(e)}")
            flash(f'Error updating trainee: {str(e)}', 'error')

    return render_template('trainees/edit.html', trainee=trainee)


@app.route('/trainees/delete/<int:trainee_id>')
def trainee_delete(trainee_id):
    """Delete trainee"""
    try:
        trainee = Trainee.query.get_or_404(trainee_id)
        db.session.delete(trainee)
        db.session.commit()
        flash('Trainee deleted successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        logger.error(f"Trainee delete error: {str(e)}")
        flash(f'Error deleting trainee: {str(e)}', 'error')

    return redirect(url_for('trainee_list'))


# ===============================
# ROUTES - MALFUNCTION MANAGEMENT
# ===============================

@app.route('/malfunctions')
def malfunction_list():
    """Display all equipment malfunctions"""
    try:
        status_filter = request.args.get('status', '')
        severity_filter = request.args.get('severity', '')

        query = EquipmentMalfunction.query
        if status_filter:
            query = query.filter_by(repair_status=status_filter)
        if severity_filter:
            query = query.filter_by(malfunction_severity=severity_filter)

        malfunctions = query.order_by(EquipmentMalfunction.report_date.desc()).all()

        # Get unique values for filters
        statuses = db.session.query(EquipmentMalfunction.repair_status.distinct()).all()
        severities = db.session.query(EquipmentMalfunction.malfunction_severity.distinct()).all()

        return render_template('malfunctions/list.html',
                               malfunctions=malfunctions,
                               statuses=[s[0] for s in statuses],
                               severities=[s[0] for s in severities],
                               current_filters={'status': status_filter, 'severity': severity_filter})
    except Exception as e:
        logger.error(f"Malfunction list error: {str(e)}")
        flash(f'Error loading malfunctions: {str(e)}', 'error')
        return render_template('malfunctions/list.html', malfunctions=[], statuses=[], severities=[])


@app.route('/malfunctions/add', methods=['GET', 'POST'])
def malfunction_add():
    if request.method == 'POST':
        try:
            malfunction = EquipmentMalfunction(
                report_date=datetime.strptime(request.form['report_date'], '%Y-%m-%d').date(),
                malfunction_severity=request.form['malfunction_severity'],
                repair_status=request.form['repair_status'],
                equipment_id=request.form['equipment_id'],
                technician_id=request.form['technician_id'] if request.form['technician_id'] else None
            )

            db.session.add(malfunction)
            db.session.commit()
            flash('Malfunction report added successfully!', 'success')
            return redirect(url_for('malfunction_list'))
        except Exception as e:
            db.session.rollback()
            logger.error(f"Malfunction add error: {str(e)}")
            flash(f'Error adding malfunction report: {str(e)}', 'error')

    equipment = Equipment.query.all()
    technicians = MaintenanceTechnician.query.all()
    return render_template('malfunctions/add.html', equipment=equipment, technicians=technicians)

# ===============================
# ROUTES - ANALYTICS & REPORTS
# ===============================

@app.route('/analytics')
def analytics():
    """Analytics dashboard with charts and reports"""
    try:
        # Equipment by type
        equipment_by_type = db.session.query(
            Equipment.equipment_type,
            db.func.count(Equipment.equipment_id)
        ).group_by(Equipment.equipment_type).all()

        # Malfunctions by month
        malfunction_by_month = db.session.query(
            db.func.date_trunc('month', EquipmentMalfunction.report_date).label('month'),
            db.func.count(EquipmentMalfunction.malfunction_id)
        ).group_by('month').order_by('month').all()

        # Training program participation
        program_participation = db.session.query(
            TrainingProgram.programname,
            db.func.count(TrainingLog.logid)
        ).join(TrainingLog).group_by(TrainingProgram.programname).all()

        return render_template('analytics.html',
                               equipment_by_type=equipment_by_type,
                               malfunction_by_month=malfunction_by_month,
                               program_participation=program_participation)
    except Exception as e:
        logger.error(f"Analytics error: {str(e)}")
        flash(f'Error loading analytics: {str(e)}', 'error')
        return render_template('analytics.html', equipment_by_type=[], malfunction_by_month=[], program_participation=[])


@app.route('/reports')
def reports():
    """Predefined reports page"""
    return render_template('reports.html')


@app.route('/api/upcoming-inspections')
def api_upcoming_inspections():
    """API endpoint for upcoming inspections"""
    try:
        # Equipment that hasn't been inspected in 30 days
        cutoff_date = datetime.now().date() - timedelta(days=30)

        equipment_needing_inspection = db.session.query(Equipment).outerjoin(SafetyCheck).filter(
            db.or_(
                SafetyCheck.inspection_date < cutoff_date,
                SafetyCheck.inspection_date.is_(None)
            )
        ).all()

        result = []
        for eq in equipment_needing_inspection:
            last_check = SafetyCheck.query.filter_by(equipment_id=eq.equipment_id).order_by(
                SafetyCheck.inspection_date.desc()).first()
            result.append({
                'equipment_id': eq.equipment_id,
                'equipment_name': eq.equipment_name,
                'equipment_type': eq.equipment_type,
                'last_inspection': last_check.inspection_date.strftime('%Y-%m-%d') if last_check else 'Never',
                'days_overdue': (datetime.now().date() - (last_check.inspection_date if last_check else eq.installation_date)).days
            })

        return jsonify(result)
    except Exception as e:
        logger.error(f"Upcoming inspections API error: {str(e)}")
        return jsonify({'error': str(e)}), 500


# ===============================
# UTILITY ROUTES
# ===============================

@app.route('/health')
def health_check():
    """Health check endpoint"""
    try:
        # Test database connection
        db.session.execute(db.text('SELECT 1'))
        return jsonify({
            'status': 'healthy',
            'database': 'connected',
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        return jsonify({
            'status': 'unhealthy',
            'database': 'disconnected',
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500


@app.route('/db-info')
def db_info():
    """Database information endpoint"""
    try:
        # Get database version
        result = db.session.execute(db.text('SELECT version()'))
        db_version = result.fetchone()[0]

        # Get table counts
        table_counts = {}
        for table in db.metadata.tables.keys():
            try:
                count = db.session.execute(db.text(f'SELECT COUNT(*) FROM {table}')).fetchone()[0]
                table_counts[table] = count
            except:
                table_counts[table] = 'Error'

        return jsonify({
            'database_version': db_version,
            'table_counts': table_counts,
            'connection_url': app.config['SQLALCHEMY_DATABASE_URI'].split('@')[1] if '@' in app.config['SQLALCHEMY_DATABASE_URI'] else 'Hidden'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ===============================
# ERROR HANDLERS
# ===============================

@app.errorhandler(404)
def not_found(error):
    return render_template('errors/404.html'), 404


@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('errors/500.html'), 500


# ===============================
# APPLICATION STARTUP (המשך create_sample_data)
# ===============================

def create_sample_data():
    """Create sample data for testing (optional)"""
    try:
        if Trainee.query.first():
            logger.info("Sample data already exists.")
            return

        logger.info("Creating sample data...")

        # Create sample trainee
        sample_trainee = Trainee(
            firstname='John',
            lastname='Doe',
            email='john.doe@example.com',
            phone='050-1234567',
            dateofbirth=datetime(1995, 5, 15).date()
        )

        # Create sample training program
        sample_program = TrainingProgram(
            programname='Weight Loss Program',
            startdate=datetime(2025, 1, 1).date(),
            enddate=datetime(2025, 12, 31).date(),
            trainee=sample_trainee
        )

        # Create sample exercise
        sample_exercise = Exercise(
            exname='Running',
            description='Treadmill running exercise',
            training_program=sample_program
        )

        # Create sample safety standard
        sample_standard = SafetyStandard(
            standard_name='ISO-9001',
            safety_requirements_description='Standard gym equipment safety requirements.',
            standard_level='High',
            equipment_type='Cardio'
        )

        # Create sample equipment
        sample_equipment = Equipment(
            equipment_name='Treadmill X200',
            equipment_type='Cardio',
            safety_status='Active',
            installation_date=datetime(2024, 6, 1).date(),
            conditionstatus='Good',
            purchasedate=datetime(2024, 5, 15).date(),
            safety_standard=sample_standard,
            exercise=sample_exercise
        )

        # Create sample employee and technician
        sample_employee = Employee(
            phone_number='050-7654321'
        )

        sample_technician = MaintenanceTechnician(
            full_name='Jane Smith',
            professional_certifications='Certified Technician',
            phone_number='050-8888888',
            last_certification_date=datetime(2024, 1, 1).date(),
            employee=sample_employee
        )

        # Create sample equipment malfunction
        sample_malfunction = EquipmentMalfunction(
            report_date=datetime(2025, 6, 15).date(),
            malfunction_severity='Medium',
            repair_status='Pending',
            equipment=sample_equipment,
            technician=sample_technician
        )

        # Create sample training log
        sample_log = TrainingLog(
            trainee=sample_trainee,
            program=sample_program,
            duration=60,
            repetitions=10,
            programname='Weight Loss Program'
        )

        # Create sample safety check
        sample_safety_check = SafetyCheck(
            equipment=sample_equipment,
            result='Pass',
            inspector_notes='All checks passed.',
            inspection_date=datetime(2025, 5, 1).date()
        )

        db.session.add_all([
            sample_trainee, sample_program, sample_exercise,
            sample_standard, sample_equipment,
            sample_employee, sample_technician,
            sample_malfunction, sample_log, sample_safety_check
        ])
        db.session.commit()

        logger.info("Sample data created successfully.")
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error creating sample data: {str(e)}")


# ===============================
# MAIN ENTRY POINT
# ===============================

if __name__ == '__main__':
    with app.app_context():
        if test_db_connection():
            try:
                db.create_all()
                logger.info("✅ Database tables are ready.")
            except Exception as e:
                logger.error(f"❌ Error setting up the database: {str(e)}")
        else:
            logger.error("❌ Exiting due to database connection failure.")
            sys.exit(1)

    app.run(debug=True, host='0.0.0.0', port=5000)
